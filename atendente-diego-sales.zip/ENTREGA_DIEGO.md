# Entrega — Diego Sales (pronto para instalar)

**Titular:** Diego Sales — Coordenador Comercial de Planos de Saúde | Palestrante Motivacional Premium
**WhatsApp comercial:** 55 21 98384-3924 · **E-mail:** diegoconsultordeplano@gmail.com
**Site:** https://consultoriadeplano.com.br/

## Horários configurados no robô
- Segunda: 09:00 às 19:30 · Terça: 09:00 às 19:30 · Quarta: 09:00 às 18:00 · Quinta: 09:00 às 19:30
- Sexta: 09:00 às 17:00 · Sábado e Domingo: fechado

## O que o robô já faz (automático, com boas-vindas)
1. Dá **boas-vindas** com seu nome + opções (cotação / palestra / agendar) + site
2. Informa **horário**, **preço de referência** dos 3 planos + pede idade/cidade/tipo p/ cotação exata
3. Apresenta **palestras** (temas, duração, formato) e monta proposta em 24h
4. **Agenda** reunião (nome + dia/horário + tipo) no Google Calendar ou arquivo local
5. Transfere para **humano**, trata **urgência** (orienta 192) e avisa **fora de horário**

## Diego instala sozinho (controle total)
1. Instala Python 3.11+ e Docker Desktop
2. Copia esta pasta, 2 cliques em **`install.bat`**
3. (Opcional) cola chave Gemini grátis no `.env` — sem chave funciona em modo simples
4. 2 cliques em **`start-evolution.bat`** → `python conectar_whatsapp.py` → escaneia o QR com o WhatsApp 21 98384-3924
5. 2 cliques em **`start.bat`** → testa mandando "oi" de outro celular
6. Google Calendar: `credentials.json` na pasta + `python setup_google.py` (1 vez)
7. Personalizar quando quiser: **`python configurar.py`** (nome, horários, preços, boas-vindas — sem programar)

Detalhe passo a passo: `PASSO_A_PASSO_CLIENTE.md`. Permissão/acesso: `PEDIR_AUTORIZACAO.md`.
Para desligar: feche o `start.bat` + `docker compose down` + WhatsApp → Aparelhos conectados → remover.
