/* ============================================================
   KARINE 2.8 — 28º Aniversário
   Cena 3D interativa + carrossel de fotos + festa
   ============================================================ */
(function () {
  'use strict';

  var $ = function (s) { return document.querySelector(s); };
  var $$ = function (s) { return Array.prototype.slice.call(document.querySelectorAll(s)); };

  /* ---------------------------------------------------------
     TOAST
  --------------------------------------------------------- */
  var toastEl = $('#toast'), toastTimer;
  function toast(msg, ms) {
    if (!toastEl) return;
    toastEl.textContent = msg;
    toastEl.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { toastEl.classList.remove('show'); }, ms || 3400);
  }

  /* ---------------------------------------------------------
     PRELOADER
  --------------------------------------------------------- */
  var pre = $('#preloader'), preHidden = false;
  function hidePre() {
    if (preHidden || !pre) return;
    preHidden = true;
    pre.classList.add('hide');
    setTimeout(function () { pre.style.display = 'none'; }, 900);
  }
  window.addEventListener('load', function () { setTimeout(hidePre, 650); });
  setTimeout(hidePre, 3400);

  /* ---------------------------------------------------------
     REVEAL ON SCROLL
  --------------------------------------------------------- */
  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); }
      });
    }, { threshold: 0.14 });
    $$('.reveal').forEach(function (el) { io.observe(el); });
  } else {
    $$('.reveal').forEach(function (el) { el.classList.add('in'); });
  }

  /* ---------------------------------------------------------
     CURSOR GLOW
  --------------------------------------------------------- */
  var glow = $('#cursorGlow'), gx = innerWidth / 2, gy = innerHeight / 2, gtx = gx, gty = gy;
  window.addEventListener('pointermove', function (e) {
    if (e.pointerType === 'mouse') {
      document.body.classList.add('has-mouse');
      gtx = e.clientX; gty = e.clientY;
    }
  }, { passive: true });

  /* =========================================================
     CENA 3D (three.js)
  ========================================================= */
  var has3D = !!window.THREE;
  var renderer, scene, camera, clock;
  var sparkles, sparkleData = null, halo;
  var cake, baseCakeY = 0, flames = [], flameLight, flameOn = true;
  var hearts = [], balloons = [];
  var confetti = [], confettiI = 0;
  var smoke = null, smokeActive = false, smokeLife = 0;
  var mouse3 = { x: 0, y: 0, tx: 0, ty: 0 };
  var relightTimer = null;

  var MOBILE = matchMedia('(max-width:768px)').matches ||
               (navigator.hardwareConcurrency || 8) <= 4;

  function makeGlowTexture(inner, mid, outer) {
    var c = document.createElement('canvas'); c.width = c.height = 64;
    var g = c.getContext('2d');
    var grd = g.createRadialGradient(32, 32, 0, 32, 32, 32);
    grd.addColorStop(0, inner);
    grd.addColorStop(0.35, mid);
    grd.addColorStop(1, outer);
    g.fillStyle = grd; g.fillRect(0, 0, 64, 64);
    return new THREE.CanvasTexture(c);
  }

  function heartGeometry() {
    var s = new THREE.Shape();
    s.moveTo(0, 0.55);
    s.bezierCurveTo(0, 0.55, -0.45, 0.95, -0.95, 0.5);
    s.bezierCurveTo(-1.45, 0.05, -0.95, -0.5, 0, -1);
    s.bezierCurveTo(0.95, -0.5, 1.45, 0.05, 0.95, 0.5);
    s.bezierCurveTo(0.45, 0.95, 0, 0.55, 0, 0.55);
    var geo = new THREE.ExtrudeGeometry(s, {
      depth: 0.24, bevelEnabled: true, bevelSegments: 2,
      bevelSize: 0.07, bevelThickness: 0.07, curveSegments: 10
    });
    geo.center();
    return geo;
  }

  function buildEnvironment() {
    try {
      var c = document.createElement('canvas'); c.width = 128; c.height = 64;
      var g = c.getContext('2d');
      var grd = g.createLinearGradient(0, 0, 0, 64);
      grd.addColorStop(0, '#eaf4ff');
      grd.addColorStop(0.45, '#a9c8e8');
      grd.addColorStop(0.62, '#f2dfa8');
      grd.addColorStop(0.8, '#d4af37');
      grd.addColorStop(1, '#3f5f80');
      g.fillStyle = grd; g.fillRect(0, 0, 128, 64);
      var tex = new THREE.CanvasTexture(c);
      tex.mapping = THREE.EquirectangularReflectionMapping;
      var rt = new THREE.WebGLCubeRenderTarget(128);
      rt.fromEquirectangular(renderer, tex);
      scene.environment = rt.texture;
      tex.dispose();
    } catch (err) { /* sem ambiente, segue o baile */ }
  }

  function goldMat(shininess) {
    return new THREE.MeshStandardMaterial({
      color: 0xe6c168, metalness: 0.85, roughness: 0.28,
      emissive: 0x2e2205, emissiveIntensity: 0.5
    });
  }

  function buildCake() {
    var g = new THREE.Group();
    var gold = goldMat();
    var goldBright = new THREE.MeshStandardMaterial({
      color: 0xf3dc9a, metalness: 0.9, roughness: 0.22,
      emissive: 0x332605, emissiveIntensity: 0.55
    });
    var cream = new THREE.MeshStandardMaterial({ color: 0xf6eed8, metalness: 0.2, roughness: 0.5 });

    // prato
    var plate = new THREE.Mesh(new THREE.CylinderGeometry(2.85, 2.95, 0.16, 56), goldBright);
    plate.position.y = 0.08; g.add(plate);

    // camadas do bolo
    var t1 = new THREE.Mesh(new THREE.CylinderGeometry(2.05, 2.05, 1.25, 56), gold);
    t1.position.y = 0.78; g.add(t1);
    var t2 = new THREE.Mesh(new THREE.CylinderGeometry(1.45, 1.45, 1.0, 56), gold);
    t2.position.y = 1.9; g.add(t2);

    // molduras douradas
    var ring1 = new THREE.Mesh(new THREE.TorusGeometry(2.05, 0.1, 12, 60), goldBright);
    ring1.rotation.x = Math.PI / 2; ring1.position.y = 1.38; g.add(ring1);
    var ring2 = new THREE.Mesh(new THREE.TorusGeometry(1.45, 0.09, 12, 60), goldBright);
    ring2.rotation.x = Math.PI / 2; ring2.position.y = 2.38; g.add(ring2);
    var ringBase = new THREE.Mesh(new THREE.TorusGeometry(2.05, 0.09, 12, 60), goldBright);
    ringBase.rotation.x = Math.PI / 2; ringBase.position.y = 0.2; g.add(ringBase);

    // pérolas na base do bolo de cima
    var pearlGeo = new THREE.SphereGeometry(0.09, 12, 10);
    for (var p = 0; p < 18; p++) {
      var a = (p / 18) * Math.PI * 2;
      var pearl = new THREE.Mesh(pearlGeo, cream);
      pearl.position.set(Math.cos(a) * 1.45, 2.38, Math.sin(a) * 1.45);
      g.add(pearl);
    }

    // velas
    var candleGeo = new THREE.CylinderGeometry(0.055, 0.055, 0.85, 12);
    var candleMat = new THREE.MeshStandardMaterial({ color: 0xf3efe2, roughness: 0.6, metalness: 0.05 });
    var stripeMat = new THREE.MeshStandardMaterial({ color: 0x9fc0e2, roughness: 0.6 });
    var flameMat = new THREE.MeshBasicMaterial({ color: 0xffc061, transparent: true, opacity: 0.96 });
    var flameGeo = new THREE.ConeGeometry(0.095, 0.3, 12);

    for (var i = 0; i < 5; i++) {
      var ang = (i / 5) * Math.PI * 2 - Math.PI / 2;
      var cx = Math.cos(ang) * 0.72, cz = Math.sin(ang) * 0.72;
      var candle = new THREE.Mesh(candleGeo, i % 2 ? stripeMat : candleMat);
      candle.position.set(cx, 2.8 + 0.42, cz);
      g.add(candle);
      var flame = new THREE.Mesh(flameGeo, flameMat.clone());
      flame.position.set(cx, 2.8 + 0.85 + 0.17, cz);
      flame.userData.phase = i * 1.7;
      g.add(flame);
      flames.push(flame);
    }

    flameLight = new THREE.PointLight(0xffa640, 1.6, 14, 2);
    flameLight.position.set(0, 4.1, 0.4);
    g.add(flameLight);

    return g;
  }

  function buildScene() {
    var canvas = $('#cena3d');
    renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: !MOBILE, alpha: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, MOBILE ? 1.5 : 2));
    renderer.setSize(innerWidth, innerHeight);

    scene = new THREE.Scene();
    camera = new THREE.PerspectiveCamera(55, innerWidth / innerHeight, 0.1, 120);
    camera.position.set(0, 0, 14);
    clock = new THREE.Clock();

    buildEnvironment();

    // luzes
    scene.add(new THREE.AmbientLight(0x9dbbdd, 0.55));
    scene.add(new THREE.HemisphereLight(0xd6e9ff, 0x3a5877, 0.75));
    var sun = new THREE.DirectionalLight(0xfff2d4, 1.05);
    sun.position.set(7, 10, 8); scene.add(sun);
    var blue = new THREE.PointLight(0x86b6e8, 0.85, 70);
    blue.position.set(-11, 5, 7); scene.add(blue);
    var gold = new THREE.PointLight(0xffd98a, 0.7, 60);
    gold.position.set(10, -4, 6); scene.add(gold);

    /* ---- partículas douradas ---- */
    var count = MOBILE ? 420 : 900;
    var pos = new Float32Array(count * 3);
    var spd = new Float32Array(count);
    for (var i = 0; i < count; i++) {
      pos[i * 3] = (Math.random() - 0.5) * 34;
      pos[i * 3 + 1] = (Math.random() - 0.5) * 22;
      pos[i * 3 + 2] = -14 + Math.random() * 18;
      spd[i] = 0.14 + Math.random() * 0.5;
    }
    var sGeo = new THREE.BufferGeometry();
    sGeo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    var sTex = makeGlowTexture('rgba(255,247,222,1)', 'rgba(243,226,174,.7)', 'rgba(243,226,174,0)');
    sparkles = new THREE.Points(sGeo, new THREE.PointsMaterial({
      size: 0.32, map: sTex, transparent: true, depthWrite: false,
      blending: THREE.AdditiveBlending, color: 0xffdfa0, opacity: 0.88
    }));
    sparkleData = { spd: spd, count: count };
    scene.add(sparkles);

    /* ---- anel dourado (halo atrás do 28) ---- */
    halo = new THREE.Mesh(
      new THREE.TorusGeometry(4.9, 0.055, 10, 140),
      new THREE.MeshStandardMaterial({
        color: 0xf0d78b, metalness: 0.9, roughness: 0.25,
        emissive: 0x2e2205, emissiveIntensity: 0.6
      })
    );
    halo.position.set(0, 0.7, -5.5);
    halo.rotation.x = 0.22;
    scene.add(halo);

    /* ---- corações flutuantes ---- */
    var hGeo = MOBILE ? null : heartGeometry();
    if (!hGeo) hGeo = new THREE.SphereGeometry(0.5, 16, 12); // fallback simples
    var heartMats = [
      new THREE.MeshStandardMaterial({ color: 0xf0d78f, metalness: 0.72, roughness: 0.3, emissive: 0x3a2c08, emissiveIntensity: 0.6 }),
      new THREE.MeshStandardMaterial({ color: 0xa9c8e8, metalness: 0.6, roughness: 0.32, emissive: 0x16222f, emissiveIntensity: 0.55 }),
      new THREE.MeshStandardMaterial({ color: 0xf9eed0, metalness: 0.5, roughness: 0.35, emissive: 0x2f2a18, emissiveIntensity: 0.5 })
    ];
    var nHearts = MOBILE ? 8 : 15;
    for (var h = 0; h < nHearts; h++) {
      var hm = new THREE.Mesh(hGeo, heartMats[h % 3]);
      var side = Math.random() > 0.5 ? 1 : -1;
      hm.position.set(
        side * (3.4 + Math.random() * 9),
        (Math.random() - 0.5) * 13,
        -9 + Math.random() * 11
      );
      var sc = 0.28 + Math.random() * 0.5;
      hm.scale.setScalar(sc);
      hm.rotation.z = (Math.random() - 0.5) * 0.9;
      hm.userData = {
        baseY: hm.position.y, phase: Math.random() * Math.PI * 2,
        bob: 0.4 + Math.random() * 0.8, spin: 0.3 + Math.random() * 0.5
      };
      hearts.push(hm); scene.add(hm);
    }

    /* ---- balões ---- */
    var bMats = [
      new THREE.MeshStandardMaterial({ color: 0xe6c168, metalness: 0.8, roughness: 0.3, emissive: 0x2b2005, emissiveIntensity: 0.4 }),
      new THREE.MeshStandardMaterial({ color: 0x8fb6dd, metalness: 0.6, roughness: 0.34, emissive: 0x101d2b, emissiveIntensity: 0.45 }),
      new THREE.MeshStandardMaterial({ color: 0xf7f2e4, metalness: 0.4, roughness: 0.4, emissive: 0x1c1c1c, emissiveIntensity: 0.3 })
    ];
    var bGeo = new THREE.SphereGeometry(0.52, 22, 16);
    var strGeo = new THREE.BufferGeometry().setFromPoints([
      new THREE.Vector3(0, -0.56, 0), new THREE.Vector3(0, -2.1, 0)
    ]);
    var strMat = new THREE.LineBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.35 });
    var nB = MOBILE ? 4 : 7;
    for (var b = 0; b < nB; b++) {
      var grp = new THREE.Group();
      var bal = new THREE.Mesh(bGeo, bMats[b % 3]);
      grp.add(bal);
      grp.add(new THREE.Line(strGeo, strMat));
      var bx = (Math.random() > 0.5 ? 1 : -1) * (4.5 + Math.random() * 7);
      grp.position.set(bx, -8 + Math.random() * 15, -8 + Math.random() * 5);
      grp.userData = {
        baseX: grp.position.x, speed: 0.24 + Math.random() * 0.4,
        phase: Math.random() * Math.PI * 2
      };
      balloons.push(grp); scene.add(grp);
    }

    /* ---- bolo ---- */
    cake = buildCake();
    scene.add(cake);

    /* ---- confete (pool) ---- */
    var nConf = MOBILE ? 90 : 150;
    var confGeo = new THREE.PlaneGeometry(0.17, 0.26);
    var confColors = [0xf3e2ae, 0xd4af37, 0xfdfaf3, 0xa9c8e8, 0xf0b7c4, 0x9be3c4];
    for (var k = 0; k < nConf; k++) {
      var m = new THREE.Mesh(confGeo, new THREE.MeshBasicMaterial({
        color: confColors[k % confColors.length],
        side: THREE.DoubleSide, transparent: true, opacity: 1
      }));
      m.visible = false;
      m.userData = { vel: new THREE.Vector3(), rot: new THREE.Vector3(), life: 0 };
      confetti.push(m); scene.add(m);
    }

    /* ---- fumaça das velas ---- */
    var smCount = 60;
    var smPos = new Float32Array(smCount * 3);
    var smGeo = new THREE.BufferGeometry();
    smGeo.setAttribute('position', new THREE.BufferAttribute(smPos, 3));
    var smTex = makeGlowTexture('rgba(230,238,246,.9)', 'rgba(200,214,228,.45)', 'rgba(200,214,228,0)');
    smoke = new THREE.Points(smGeo, new THREE.PointsMaterial({
      size: 0.5, map: smTex, transparent: true, opacity: 0,
      depthWrite: false, color: 0xdde7f1
    }));
    smoke.visible = false;
    smoke.userData = { vel: new Float32Array(smCount), count: smCount };
    scene.add(smoke);

    layout3D();
  }

  /* posiciona os elementos conforme a proporção da tela */
  function layout3D() {
    if (!cake) return;
    var a = innerWidth / innerHeight;
    if (a < 0.9) {            // retrato (celular)
      cake.position.set(-1.9, -7.4, 0); cake.scale.setScalar(0.85); baseCakeY = -7.4;
      if (halo) { halo.position.set(0, 1.6, -5.5); halo.scale.setScalar(0.8); }
    } else if (a < 1.45) {    // quase quadrado / tablet
      cake.position.set(-4.6, -6.4, 0); cake.scale.setScalar(0.95); baseCakeY = -6.4;
      if (halo) { halo.position.set(0, 1.1, -5.5); halo.scale.setScalar(0.92); }
    } else {                  // desktop
      cake.position.set(-7.4, -5.0, 0); cake.scale.setScalar(1.05); baseCakeY = -5.0;
      if (halo) { halo.position.set(0, 0.7, -5.5); halo.scale.setScalar(1); }
    }
  }

  /* converte coordenadas de tela em mundo (plano z = 0) */
  function screenToWorld(cx, cy) {
    var v = new THREE.Vector3((cx / innerWidth) * 2 - 1, -(cy / innerHeight) * 2 + 1, 0.5);
    v.unproject(camera);
    var dir = v.sub(camera.position).normalize();
    var dist = -camera.position.z / dir.z;
    return camera.position.clone().add(dir.multiplyScalar(dist));
  }

  function burst(origin, amount) {
    if (!confetti.length) return;
    amount = Math.min(amount || 80, confetti.length);
    for (var i = 0; i < amount; i++) {
      var m = confetti[confettiI];
      confettiI = (confettiI + 1) % confetti.length;
      m.visible = true;
      m.position.copy(origin);
      m.position.x += (Math.random() - 0.5) * 0.5;
      m.position.y += (Math.random() - 0.5) * 0.5;
      m.userData.vel.set(
        (Math.random() - 0.5) * 7,
        3.2 + Math.random() * 5.5,
        (Math.random() - 0.5) * 2.5
      );
      m.userData.rot.set(
        (Math.random() - 0.5) * 9,
        (Math.random() - 0.5) * 9,
        (Math.random() - 0.5) * 9
      );
      m.rotation.set(Math.random() * 3, Math.random() * 3, Math.random() * 3);
      m.userData.life = 2.2 + Math.random() * 1.4;
      m.material.opacity = 1;
      m.scale.setScalar(0.8 + Math.random() * 0.7);
    }
  }

  function cakeTopWorld() {
    if (!cake) return new THREE.Vector3(0, 0, 0);
    var v = new THREE.Vector3(0, 3.9, 0);
    return cake.localToWorld(v);
  }

  function ligarVelas() {
    flames.forEach(function (f) { f.visible = true; });
    if (flameLight) flameLight.intensity = 1.6;
    flameOn = true;
    if (smoke) { smoke.visible = false; }
    smokeActive = false;
  }

  function apagarVelas() {
    if (!flameOn) { toast('As velas já estão apagadas — é só pedir o desejo! 🤫'); return; }
    flames.forEach(function (f) { f.visible = false; });
    if (flameLight) flameLight.intensity = 0;
    flameOn = false;

    // fumaça subindo
    if (smoke) {
      var pos = smoke.geometry.attributes.position.array;
      var top = cakeTopWorld();
      for (var i = 0; i < smoke.userData.count; i++) {
        pos[i * 3] = top.x + (Math.random() - 0.5) * 1.7;
        pos[i * 3 + 1] = top.y + (Math.random() - 0.5) * 0.4;
        pos[i * 3 + 2] = top.z + (Math.random() - 0.5) * 1.7;
        smoke.userData.vel[i] = 0.7 + Math.random() * 1.2;
      }
      smoke.geometry.attributes.position.needsUpdate = true;
      smoke.visible = true;
      smoke.material.opacity = 0.75;
      smokeActive = true; smokeLife = 3.2;
    }

    burst(cakeTopWorld(), MOBILE ? 60 : 110);
    toast('Você apagou as velas! 🎁 Agora é só fechar os olhos e pedir o desejo… ♥', 4200);
    clearTimeout(relightTimer);
    relightTimer = setTimeout(function () {
      ligarVelas();
      toast('As velas voltaram acesas! ✨ Mais uma volta ao sol pra Karine!');
    }, 7000);
  }

  /* ---------------------------------------------------------
     LOOP DE ANIMAÇÃO
  --------------------------------------------------------- */
  function animate() {
    requestAnimationFrame(animate);
    var dt = Math.min(clock.getDelta(), 0.05);
    var t = clock.elapsedTime;

    // parallax suave da câmera
    mouse3.x += (mouse3.tx - mouse3.x) * 0.045;
    mouse3.y += (mouse3.ty - mouse3.y) * 0.045;
    camera.position.x = mouse3.x * 1.5;
    camera.position.y = mouse3.y * 0.95;
    camera.lookAt(0, 0, 0);

    // brilhos subindo
    if (sparkleData) {
      var arr = sparkles.geometry.attributes.position.array;
      var spd = sparkleData.spd;
      for (var i = 0; i < sparkleData.count; i++) {
        var y = i * 3 + 1;
        arr[y] += spd[i] * dt;
        if (arr[y] > 11.5) {
          arr[y] = -11.5;
          arr[i * 3] = (Math.random() - 0.5) * 34;
          arr[i * 3 + 2] = -14 + Math.random() * 18;
        }
      }
      sparkles.geometry.attributes.position.needsUpdate = true;
      sparkles.material.opacity = 0.72 + Math.sin(t * 1.4) * 0.18;
    }

    // halo
    if (halo) {
      halo.rotation.z += dt * 0.12;
      halo.rotation.y = Math.sin(t * 0.3) * 0.16;
    }

    // corações (giram de lado a lado, nunca de costas)
    for (var h = 0; h < hearts.length; h++) {
      var hm = hearts[h], u = hm.userData;
      hm.position.y = u.baseY + Math.sin(t * u.bob + u.phase) * 0.7;
      hm.rotation.y = Math.sin(t * u.spin + u.phase) * 0.75;
      hm.rotation.z = Math.sin(t * 0.6 + u.phase) * 0.28;
    }

    // balões
    for (var b = 0; b < balloons.length; b++) {
      var bg = balloons[b], bu = bg.userData;
      bg.position.y += bu.speed * dt;
      bg.position.x = bu.baseX + Math.sin(t * 0.55 + bu.phase) * 0.6;
      bg.rotation.z = Math.sin(t * 0.8 + bu.phase) * 0.12;
      if (bg.position.y > 10.5) {
        bg.position.y = -10.5;
        bu.baseX = (Math.random() > 0.5 ? 1 : -1) * (4.5 + Math.random() * 7);
        bg.position.z = -8 + Math.random() * 5;
      }
    }

    // bolo (respira) + velas (piscam)
    if (cake) {
      cake.position.y = baseCakeY + Math.sin(t * 0.85) * 0.16;
      cake.rotation.y = -0.32 + Math.sin(t * 0.28) * 0.14;
      if (flameOn) {
        for (var f = 0; f < flames.length; f++) {
          var fl = flames[f];
          var s = 1 + Math.sin(t * 13 + fl.userData.phase) * 0.17;
          fl.scale.set(s, s * (1 + Math.sin(t * 17 + fl.userData.phase) * 0.12), s);
          fl.rotation.z = Math.sin(t * 9 + fl.userData.phase) * 0.14;
        }
        if (flameLight) flameLight.intensity = 1.45 + Math.sin(t * 16) * 0.3;
      }
    }

    // confete
    for (var c = 0; c < confetti.length; c++) {
      var cm = confetti[c];
      if (!cm.visible) continue;
      var u2 = cm.userData;
      u2.life -= dt;
      if (u2.life <= 0) { cm.visible = false; continue; }
      u2.vel.y -= 7.5 * dt;
      u2.vel.multiplyScalar(1 - 0.55 * dt);
      cm.position.x += u2.vel.x * dt;
      cm.position.y += u2.vel.y * dt;
      cm.position.z += u2.vel.z * dt;
      cm.rotation.x += u2.rot.x * dt;
      cm.rotation.y += u2.rot.y * dt;
      cm.rotation.z += u2.rot.z * dt;
      if (u2.life < 0.7) cm.material.opacity = u2.life / 0.7;
      if (cm.position.y < -11) cm.visible = false;
    }

    // fumaça
    if (smokeActive && smoke) {
      smokeLife -= dt;
      var sp = smoke.geometry.attributes.position.array;
      for (var s2 = 0; s2 < smoke.userData.count; s2++) {
        sp[s2 * 3 + 1] += smoke.userData.vel[s2] * dt;
        sp[s2 * 3] += Math.sin(t * 2 + s2) * 0.25 * dt;
      }
      smoke.geometry.attributes.position.needsUpdate = true;
      if (smokeLife < 1.4) smoke.material.opacity = Math.max(0, smokeLife / 1.4) * 0.75;
      if (smokeLife <= 0) { smokeActive = false; smoke.visible = false; }
    }

    // glow do cursor
    if (glow) {
      gx += (gtx - gx) * 0.12;
      gy += (gty - gy) * 0.12;
      glow.style.transform = 'translate(' + gx + 'px,' + gy + 'px)';
    }

    renderer.render(scene, camera);
  }

  /* mouse -> parallax */
  window.addEventListener('pointermove', function (e) {
    mouse3.tx = (e.clientX / innerWidth - 0.5) * 2;
    mouse3.ty = -(e.clientY / innerHeight - 0.5) * 2;
  }, { passive: true });

  window.addEventListener('resize', function () {
    if (!renderer) return;
    camera.aspect = innerWidth / innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(innerWidth, innerHeight);
    layout3D();
    layoutCarousel();
  });

  /* clique em qualquer lugar solta um pouco de confete */
  document.addEventListener('click', function (e) {
    if (!renderer) return;
    if (e.target.closest('button, a, .stage, .dock, .marca, .grande')) return;
    burst(screenToWorld(e.clientX, e.clientY), 26);
  });

  /* =========================================================
     CARROSSEL 3D
  ========================================================= */
  var stage = $('#stage'), ring = $('#ring');
  var slides = $$('.slide');
  var dotsWrap = $('#dots'), counter = $('#contador');
  var prevBtn = $('#prev'), nextBtn = $('#next'), autoBtn = $('#auto');
  var idx = 0, n = slides.length;
  var auto = false, autoTimer = null, galleryVisible = false;
  var R = 190, cardW = 320;

  function layoutCarousel() {
    if (!stage) return;
    var w = stage.clientWidth || 320;
    cardW = Math.round(Math.min(340, Math.max(230, w * 0.34)));
    if (w < 560) cardW = Math.round(Math.min(300, w * 0.72));
    // raio do anel: cartões não podem se sobrepor demais
    R = Math.round(Math.max(cardW * 0.62, (cardW / 2) / Math.tan(Math.PI / n) * 1.06));
    stage.style.setProperty('--card-w', cardW + 'px');
    stage.style.setProperty('--R', R + 'px');
    // altura do palco = foto (4/5) + legenda + folga
    var fotoH = Math.round((cardW - 20) * 1.25);
    var legenda = window.innerWidth <= 640 ? 148 : 168;
    stage.style.height = Math.min(760, fotoH + legenda + 20 + 60) + 'px';
    slides.forEach(function (s, i) {
      s.style.transform = 'translate(-50%,-50%) rotateY(' + (i * (360 / n)) + 'deg) translateZ(' + R + 'px)';
    });
  }

  function render() {
    if (!ring) return;
    ring.style.transform = 'rotateY(' + (-idx * (360 / n)) + 'deg)';
    slides.forEach(function (s, i) { s.classList.toggle('active', i === idx); });
    Array.prototype.forEach.call(dotsWrap.children, function (d, i) { d.classList.toggle('on', i === idx); });
    counter.textContent = (idx + 1) + ' / ' + n;
  }

  function goTo(i, user) {
    idx = ((i % n) + n) % n;
    render();
    if (user) restartAuto();
  }

  function restartAuto() {
    clearTimeout(autoTimer);
    if (!auto) return;
    autoTimer = setTimeout(function () { goTo(idx + 1); restartAuto(); }, 5200);
  }

  function initCarousel() {
    if (!stage) return;
    // pontos
    for (var i = 0; i < n; i++) {
      (function (i) {
        var b = document.createElement('button');
        b.type = 'button';
        b.setAttribute('aria-label', 'Foto ' + (i + 1));
        b.addEventListener('click', function () { goTo(i, true); });
        dotsWrap.appendChild(b);
      })(i);
    }
    layoutCarousel();
    render();

    prevBtn.addEventListener('click', function () { goTo(idx - 1, true); });
    nextBtn.addEventListener('click', function () { goTo(idx + 1, true); });

    autoBtn.addEventListener('click', function () {
      auto = !auto;
      autoBtn.classList.toggle('on', auto);
      autoBtn.textContent = auto ? '⏸ pausar' : '▶ passar sozinho';
      if (auto) { restartAuto(); toast('O carrossel vai passar sozinho — pode ficar tranquila! 🎞️'); }
      else { clearTimeout(autoTimer); toast('Modo manual: passe as fotos quando quiser ✋'); }
    });

    // pausa no hover (se estiver automático)
    stage.addEventListener('pointerenter', function () { clearTimeout(autoTimer); });
    stage.addEventListener('pointerleave', function () { if (auto) restartAuto(); });

    // arrastar
    var dragging = false, startX = 0, startRot = 0, moved = 0;
    stage.addEventListener('pointerdown', function (e) {
      dragging = true; moved = 0;
      startX = e.clientX;
      startRot = -idx * (360 / n);
      ring.style.transition = 'none';
      try { stage.setPointerCapture(e.pointerId); } catch (err) {}
    });
    stage.addEventListener('pointermove', function (e) {
      if (!dragging) return;
      var dx = e.clientX - startX;
      moved = Math.max(moved, Math.abs(dx));
      ring.style.transform = 'rotateY(' + (startRot + dx * 0.28) + 'deg)';
    });
    function endDrag(e) {
      if (!dragging) return;
      dragging = false;
      ring.style.transition = '';
      var dx = e.clientX - startX;
      if (moved < 6) {
        render();                       // clique limpo: volta pro lugar
        goTo(idx + 1, true);            // clicar na foto avança
        return;
      }
      var target = Math.round((startRot + dx * 0.28) / -(360 / n));
      goTo(target, true);
    }
    stage.addEventListener('pointerup', endDrag);
    stage.addEventListener('pointercancel', function () {
      dragging = false; ring.style.transition = ''; render();
    });

    // rolagem horizontal passa a foto
    var wheelLock = 0;
    stage.addEventListener('wheel', function (e) {
      if (Math.abs(e.deltaX) <= Math.abs(e.deltaY)) return; // vertical continua rolando a página
      e.preventDefault();
      var now = Date.now();
      if (now < wheelLock) return;
      wheelLock = now + 480;
      goTo(idx + (e.deltaX > 0 ? 1 : -1), true);
    }, { passive: false });

    // teclado
    window.addEventListener('keydown', function (e) {
      if (!galleryVisible) return;
      if (e.key === 'ArrowRight') { e.preventDefault(); goTo(idx + 1, true); }
      if (e.key === 'ArrowLeft') { e.preventDefault(); goTo(idx - 1, true); }
    });

    // seção visível (para o teclado)
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (es) {
        galleryVisible = es[0].isIntersecting;
      }, { threshold: 0.25 }).observe($('#galeria'));
    } else { galleryVisible = true; }
  }

  /* =========================================================
     MÚSICA — "Parabéns pra você" em Web Audio
  ========================================================= */
  var actx = null, musicOn = false, musicTimer = null, masterGain = null, liveNodes = [];

  // [frequência, início em batidas, duração em batidas]
  var MELODY = [
    [392.00, 0.0, 0.9], [392.00, 1.0, 0.9], [440.00, 2.0, 0.9], [392.00, 3.0, 0.9], [523.25, 4.0, 1.8], [493.88, 5.8, 1.8],
    [392.00, 7.6, 0.9], [392.00, 8.6, 0.9], [440.00, 9.6, 0.9], [392.00, 10.6, 0.9], [587.33, 11.6, 1.8], [523.25, 13.4, 1.8],
    [783.99, 15.2, 0.9], [783.99, 16.2, 0.9], [659.25, 17.2, 0.9], [523.25, 18.2, 0.9], [493.88, 19.2, 0.9], [440.00, 20.2, 1.6],
    [698.46, 22.0, 0.9], [698.46, 23.0, 0.9], [659.25, 24.0, 0.9], [523.25, 25.0, 0.9], [587.33, 26.0, 0.9], [523.25, 27.0, 2.8]
  ];
  var BEAT = 0.34; // segundos por batida

  function ensureAudio() {
    if (actx) return;
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    actx = new AC();
    masterGain = actx.createGain();
    masterGain.gain.value = 0.0;
    masterGain.connect(actx.destination);
  }

  function playMelody() {
    if (!actx) return;
    var start = actx.currentTime + 0.08;
    masterGain.gain.cancelScheduledValues(actx.currentTime);
    masterGain.gain.setTargetAtTime(0.5, actx.currentTime, 0.15);

    MELODY.forEach(function (note) {
      var freq = note[0], t0 = start + note[1] * BEAT, dur = note[2] * BEAT;
      // nota principal
      var o = actx.createOscillator();
      o.type = 'triangle'; o.frequency.value = freq;
      var g = actx.createGain();
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.exponentialRampToValueAtTime(0.5, t0 + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur * 0.95);
      o.connect(g); g.connect(masterGain);
      o.start(t0); o.stop(t0 + dur + 0.1);
      // brilho (oitava)
      var o2 = actx.createOscillator();
      o2.type = 'sine'; o2.frequency.value = freq * 2;
      var g2 = actx.createGain();
      g2.gain.setValueAtTime(0.0001, t0);
      g2.gain.exponentialRampToValueAtTime(0.12, t0 + 0.02);
      g2.gain.exponentialRampToValueAtTime(0.0001, t0 + dur * 0.8);
      o2.connect(g2); g2.connect(masterGain);
      o2.start(t0); o2.stop(t0 + dur + 0.1);
      liveNodes.push(o, o2);
    });

    var loopMs = (29.8 * BEAT + 1.2) * 1000;
    musicTimer = setTimeout(function () {
      if (musicOn) playMelody();
    }, loopMs);
  }

  function toggleMusic() {
    var btn = $('#acaoMusica');
    ensureAudio();
    if (!actx) { toast('Seu navegador não suporta áudio 😕'); return; }
    if (actx.state === 'suspended') actx.resume();
    musicOn = !musicOn;
    btn.classList.toggle('on', musicOn);
    btn.classList.toggle('off', !musicOn);
    if (musicOn) {
      playMelody();
      toast('🎵 Tocando “Parabéns pra você” — em dó bemol de carinho! ♥');
    } else {
      clearTimeout(musicTimer);
      masterGain.gain.setTargetAtTime(0.0, actx.currentTime, 0.12);
      setTimeout(function () {
        liveNodes.forEach(function (o) { try { o.stop(); } catch (e) {} });
        liveNodes = [];
      }, 400);
      toast('Música pausada. De novo quando quiser 🎶');
    }
  }

  /* =========================================================
     AÇÕES / EASTER EGGS
  ========================================================= */
  function initActions() {
    $('#acaoConfete').addEventListener('click', function () {
      if (!renderer) { toast('🎊 Confete! (versão sem 3D)'); return; }
      var cx = innerWidth * (0.35 + Math.random() * 0.3);
      burst(screenToWorld(cx, innerHeight * 0.35), MOBILE ? 70 : 130);
      burst(screenToWorld(innerWidth * 0.5, innerHeight * 0.55), 40);
      toast('🎊 Confete! Faça bagunça, é seu dia!');
    });

    $('#acaoVelas').addEventListener('click', function () {
      if (!renderer) { toast('🎂 Faça o desejo!'); return; }
      apagarVelas();
    });

    $('#acaoMusica').addEventListener('click', toggleMusic);

    // clique no 28 gigante
    var g28 = $('#btn28');
    if (g28) {
      g28.addEventListener('click', function () {
        toast('✨ 28 motivos pra sorrir — e você é o principal deles! ♥');
        if (renderer) burst(screenToWorld(innerWidth / 2, innerHeight * 0.4), MOBILE ? 60 : 120);
      });
    }
  }

  /* =========================================================
     BOOT
  ========================================================= */
  function boot() {
    initCarousel();
    initActions();
    if (has3D) {
      try {
        buildScene();
        animate();
      } catch (err) {
        has3D = false;
        console.warn('3D indisponível:', err);
      }
    }
    if (!has3D) document.body.classList.add('no3d');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
